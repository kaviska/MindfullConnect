import { NextRequest, NextResponse } from "next/server";
import dbConnect from "../../../lib/mongodb";
import { User } from "../../../lib/models";
import Counselor from "@/app/models/counselor";

export async function GET(req: NextRequest) {
    try {
        await dbConnect();

        const searchParams = req.nextUrl.searchParams;
        const page = parseInt(searchParams.get("page") || "1");
        const query = searchParams.get("q")?.toLowerCase() || "";

        const pageSize = 10;
        const skip = (page - 1) * pageSize;

        const filter: any = {
            role: "Counsellor",
            isActive: false,
        };

        if (query) {
            filter.$or = [
                { firstname: { $regex: query, $options: "i" } },
                { lastname: { $regex: query, $options: "i" } },
                { email: { $regex: query, $options: "i" } },
            ];
        }

        const totalCount = await Counselor.countDocuments(filter);
        const users = await Counselor.find(filter)
            .skip(skip)
            .limit(pageSize)
            .sort({ createdAt: -1 });

        return NextResponse.json({
            users,
            totalPages: Math.ceil(totalCount / pageSize),
        });
    } catch (error) {
        console.error("Error fetching pending counsellors:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
