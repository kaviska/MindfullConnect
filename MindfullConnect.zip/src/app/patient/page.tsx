import React from 'react'
import MultiActionAreaCard from "./MultiActionAreaCard"
import AboutUs from "../components/aboutUs"


import "./style.css";

import WhyChooseUs from "../components/whyChooseUs"
const page = () => {
  return (
    <div>
      {/* <WhyChooseUs/> */}
      {/* <MultiActionAreaCard /> */}
      {/* <AboutUs/> */}
      
    </div>
  )
}

export default page;










